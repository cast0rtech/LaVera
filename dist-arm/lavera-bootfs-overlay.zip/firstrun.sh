#!/usr/bin/env bash
# ==============================================================================
# LaVera Hub - First Boot Autonomous Setup
# ==============================================================================
set -euo pipefail
exec > /var/log/lavera-firstboot.log 2>&1

echo "⚡ [LaVera] Starting First-Boot Configuration..."

# 1. Setup Hostname
hostnamectl set-hostname lavera
sed -i 's/127.0.1.1.*/127.0.1.1\tlavera/' /etc/hosts || true

# 2. Extract Application Payload
BOOT_DIR="/boot/firmware"
[ ! -d "$BOOT_DIR" ] && BOOT_DIR="/boot"

mkdir -p /opt/lavera
if [ -f "${BOOT_DIR}/lavera-payload.tar.gz" ]; then
    echo "[*] Extracting LaVera application..."
    tar -xzf "${BOOT_DIR}/lavera-payload.tar.gz" -C /opt
fi

# 3. Create Persistent Systemd Service
cat << 'EOF' > /etc/systemd/system/lavera-hub.service
[Unit]
Description=LaVera All-in-One EV Telemetry Hub (Offline)
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/lavera
ExecStart=/usr/bin/python3 /opt/lavera/all-in-one/app.py
Restart=always
RestartSec=5
Environment=PORT=8080
Environment=LAVERA_DB_PATH=/opt/lavera/data/lavera.db

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable lavera-hub.service
systemctl start lavera-hub.service

# 4. Ensure mDNS / Avahi is active
systemctl enable avahi-daemon || true
systemctl start avahi-daemon || true

# 5. Clean up firstrun from cmdline.txt
if [ -f "${BOOT_DIR}/cmdline.txt" ]; then
    sed -i 's| systemd.run=/boot/firmware/firstrun.sh||g' "${BOOT_DIR}/cmdline.txt" || true
    sed -i 's| systemd.run=/boot/firstrun.sh||g' "${BOOT_DIR}/cmdline.txt" || true
fi

echo "⚡ [LaVera] First boot completed successfully! Dashboard at http://lavera.local:8080"
